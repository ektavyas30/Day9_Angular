import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FirstcomponentComponent } from './firstcomponent/firstcomponent.component';



@NgModule({
  declarations: [
    FirstcomponentComponent
  ],
  imports: [
    CommonModule
  ]
})
export class FirstmoduleModule { }
